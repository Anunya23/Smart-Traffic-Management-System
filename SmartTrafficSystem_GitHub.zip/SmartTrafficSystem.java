import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

class TrafficSignal {
    String name;
    int green;
    int red;

    public TrafficSignal(String name, int green, int red) {
        this.name = name;
        this.green = green;
        this.red = red;
    }
}

public class SmartTrafficSystem {
    private static final List<TrafficSignal> trafficSignals = Arrays.asList(
        new TrafficSignal("Uppal", 30, 60),
        new TrafficSignal("Boduppal", 45, 45),
        new TrafficSignal("Medipalli", 20, 70),
        new TrafficSignal("Ghatkesar", 50, 40)
    );

    public static String predictSignalStatus(TrafficSignal signal, LocalDateTime eta) {
        int totalCycle = signal.green + signal.red;
        int seconds = eta.getHour() * 3600 + eta.getMinute() * 60 + eta.getSecond();
        int positionInCycle = seconds % totalCycle;
        return (positionInCycle < signal.green) ? "GREEN" : "RED";
    }

    public static void simulateRoute(String start, String end) {
        System.out.println("
Route: " + start + " -> " + end);
        System.out.println("Traffic Signals Between Route: " + trafficSignals.size());

        LocalDateTime currentTime = LocalDateTime.now();
        int etaMinutes = 0;
        Random random = new Random();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("HH:mm:ss");

        for (TrafficSignal signal : trafficSignals) {
            int travelTime = random.nextInt(3) + 1;
            etaMinutes += travelTime;
            LocalDateTime eta = currentTime.plus(etaMinutes, ChronoUnit.MINUTES);
            String status = predictSignalStatus(signal, eta);

            System.out.println("
Location: " + signal.name);
            System.out.println("  ETA: " + eta.format(formatter));
            System.out.println("  Signal on arrival: " + status);

            if (status.equals("GREEN")) {
                System.out.println("  Maintain speed.");
            } else {
                System.out.println("  Slow down or prepare to stop.");
            }
        }
    }

    public static void runSmartTrafficSystem() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Smart Traffic Management System ===");
        System.out.print("Enter Starting Location: ");
        String start = scanner.nextLine();
        System.out.print("Enter Destination Location: ");
        String end = scanner.nextLine();

        simulateRoute(start, end);

        System.out.println("
Journey prediction complete. Drive safe!");
        scanner.close();
    }

    public static void main(String[] args) {
        runSmartTrafficSystem();
    }
}
